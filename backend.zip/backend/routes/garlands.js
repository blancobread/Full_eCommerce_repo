const express = require('express');
const router = express.Router();
const { getDB } = require('../db/mongoClient');
const { authenticateToken } = require('./admin');

router.get('/', async (req, res) => {
    const db = getDB();
    const garlands = await db.collection('garlands').find().toArray();
    res.json(garlands);
});

// Protected POST (admin only)
router.post('/', authenticateToken, async (req, res) => {
    const db = getDB();
    const newGarland = req.body;
    const result = await db.collection('garlands').insertOne(newGarland);
    res.json(result);
});

module.exports = router;